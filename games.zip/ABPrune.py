from checker.Game import Checker
import random

class AlphaBetaAI:
    def __init__(self, gameClass, maxDepth=5):
        self.gameClass = gameClass
        self.maxDepth = maxDepth

    def findBestMove(self, boardRepr, isMaximizingPlayer):
        bestScore, bestMove = self.alphaBeta(boardRepr, self.maxDepth, float('-inf'), float('inf'), isMaximizingPlayer)
        return bestMove

    def alphaBeta(self, boardRepr, depth, alpha, beta, isMaximizingPlayer):
        if depth == 0 or self.gameClass.getPossibleMoves(boardRepr) == []:
            return self.heuristic(boardRepr, isMaximizingPlayer), None

        if isMaximizingPlayer:
            maxEval = float('-inf')
            bestMove = None
            possibleMoves = sorted([ (self.heuristic(nextRepr, True), nextRepr, move) for nextRepr, move in self.gameClass.getPossibleMoves(boardRepr) ], reverse=True)
            for _, nextRepr, move in possibleMoves:
                eval, _ = self.alphaBeta(nextRepr, depth - 1, alpha, beta, False)
                if eval > maxEval:
                    maxEval = eval
                    bestMove = move
                alpha = max(alpha, eval)
                if beta <= alpha:
                    break
            return maxEval, bestMove
        else:
            minEval = float('inf')
            bestMove = None
            possibleMoves = [ (self.heuristic(nextRepr, False), nextRepr, move) for nextRepr, move in self.gameClass.getPossibleMoves(boardRepr) ]
            for _, nextRepr, move in possibleMoves:
                eval, _ = self.alphaBeta(nextRepr, depth - 1, alpha, beta, True)
                if eval < minEval:
                    minEval = eval
                    bestMove = move
                beta = min(beta, eval)
                if beta <= alpha:
                    break
            return minEval, bestMove

    def heuristic(self, boardRepr, isMaximizingPlayer):
        score = self.gameClass.getScore(boardRepr)
        return score + random.normalvariate( 0, 1 )

if __name__ == '__main__':
    gameClass = Checker
    ai1 = AlphaBetaAI( gameClass )
    ai2 = AlphaBetaAI( gameClass )

    game = gameClass( 'White', 'Black' )

    while True:
        print( game.board.dump() )
        print( game.board.dumpFEN() )
        print( game.board.currentTurn.color )
        if game.board.isGameOver():
            winner = game.winner(game.board.dumpFEN())
            if winner == 1:
                print( 'White wins' )
            if winner == -1:
                print( 'Black wins' )
            if winner == 0:
                print( 'Draw' )
            break
        if game.board.currentTurn.color == 'white':
            move = ai1.findBestMove( game.board.dumpFEN(), game.board.currentTurn.color == 'white' )
        else:
            move = ai2.findBestMove( game.board.dumpFEN(), game.board.currentTurn.color == 'white' )
        game.play( move )