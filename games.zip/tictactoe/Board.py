from Player import Player
from Move import Move

class Board:
    def __init__(self, player1, player2):
        self.currentTurn = player1
        self.players = [player1, player2]

    def isCellEmpty(self, x, y):
        # checking all the moves from player objects
        for player in self.players:
            for moveOfPlayer in player.moves:
                if moveOfPlayer.x == x and moveOfPlayer.y == y:
                    return False

        return True

    def canMakeMove(self, x, y):
        # only condition is target cell is empty or not
        return self.isCellEmpty(x, y)

    def play(self, x, y):
        return self.makeMove(int(x), int(y))

    def switchTurn(self):
        self.currentTurn = self.players[0] if self.currentTurn == self.players[1] else self.players[1]

    def makeMove(self, x, y):
        if not self.canMakeMove(x, y):
            return False

        self.currentTurn.moves.append(Move(self.currentTurn, x, y))
        self.switchTurn()

        return True

    def isGameOver(self):
        currentFEN = self.dumpFEN().split()[0]

        for i in range(3):
            # Check rows
            if currentFEN[i * 3] == currentFEN[i * 3 + 1] == currentFEN[i * 3 + 2] and currentFEN[i * 3] != '.':
                return currentFEN[i * 3]

            # Check columns
            if currentFEN[i] == currentFEN[i + 3] == currentFEN[i + 6] and currentFEN[i] != '.':
                return currentFEN[i]

        # Check diagonals
        if currentFEN[0] == currentFEN[4] == currentFEN[8] and currentFEN[0] != '.':
            return currentFEN[0]

        if currentFEN[2] == currentFEN[4] == currentFEN[6] and currentFEN[2] != '.':
            return currentFEN[2]

        # Check for a draw
        if '.' not in currentFEN:
            return 'draw'

        return 'ongoing'

    def calculateFENPosition(self, x, y):
        mapping = {
            (1, 1): 6,
            (1, 2): 7,
            (1, 3): 8,
            (2, 1): 3,
            (2, 2): 4,
            (2, 3): 5,
            (3, 1): 0,
            (3, 2): 1,
            (3, 3): 2
        }

        return mapping.get((x, y), None)

    def calculateXYFromFenPosition(self, index):
        x = index // 3 + 1
        y = index % 3 + 1
        return x, y

    def dump(self):
        # initial empty board
        board = [['.' for _ in range(3)] for _ in range(3)]

        # fill board with the player moves
        for player in self.players:
            for moveOfPlayer in player.moves:
               board[3-moveOfPlayer.y][moveOfPlayer.x-1] = player.color

        # display the row indexes
        board_with_labels = ['  a b c']
        for i, row in enumerate(board):
            row_label = f'{3 - i} ' + ' '.join(row)
            board_with_labels.append(row_label)

        return '\n'.join(board_with_labels)

    def dumpFEN(self):
        # initial empty board FEN representation
        initialFEN = ['.' for _ in range(9)]

        # fill FEN with the player moves
        for player in self.players:
            for moveOfPlayer in player.moves:
                FENPosition = self.calculateFENPosition(moveOfPlayer.y, moveOfPlayer.x)
                initialFEN[FENPosition] = moveOfPlayer.player.color

        return ''.join(initialFEN) + f' {self.currentTurn.color}'

    @classmethod
    def load(cls, board_string):
        gameboard = Board( Player('X', 'x'), Player('O', 'o') )
        rows = board_string.strip().split('\n')

        for i, row in enumerate(rows[1:], 1):
            cols = row.split()[1:]
            for j, color in enumerate(cols):
                if color != '.':
                    if color == gameboard.players[0].color:
                        gameboard.players[0].moves.append(Move(gameboard.players[0], i, j+1))
                    else:
                        gameboard.players[1].moves.append(Move(gameboard.players[1], i, j+1))
        return gameboard

    @classmethod
    def loadFEN(cls, fen):
        fields = fen.split()
        if len(fields) != 2:
            raise ValueError("Invalid FEN string")

        player1 = Player('X', 'x')
        player2 = Player('O', 'o')
        board = cls(player1, player2)

        for i, cellContent in enumerate(fields[0]):
            if not cellContent == '.':
                x, y = board.calculateXYFromFenPosition(i)
                if board.players[0].color == cellContent:
                    board.players[0].moves.append(Move(board.players[0], x, y))
                else:
                    board.players[1].moves.append(Move(board.players[1], x, y))

        board.currentTurn = player1 if fields[1] == 'x' else player2

        return board
