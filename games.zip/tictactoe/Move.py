class Move:
    def __init__(self, player, x, y):
        self.player = player
        self.x = x
        self.y = y