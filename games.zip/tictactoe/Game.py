from GameBase import GameBase
from Board import Board
from Player import Player

valid_inputs = ['1a', '1b', '1c', '2a', '2b', '2c', '3a', '3b', '3c']

class TicTacToe ( GameBase ):
    def __init__(self, player1, player2):
        self.player1 = Player(player1, "x")
        self.player2 = Player(player2, "o")
        self.board = Board(player1, player2).loadFEN(self.getInitialRepr())

    @classmethod
    def getInitialRepr( cls ):
        return '......... x'

    @classmethod
    def isGameOver(cls, repr):
        return Board.loadFEN(repr).isGameOver() in ['o', 'x', 'draw']

    @classmethod
    def winner(cls, repr):
        s = Board.loadFEN(repr).isGameOver()
        return 1 if s == 'x' else (-1 if s == 'o' else 0)

    @classmethod
    def getScore(cls, repr):
        board = Board.loadFEN(repr)
        game_result = board.isGameOver()

        if game_result == board.players[0].color:
            return 1
        elif game_result == board.players[1].color:
            return -1
        elif game_result == 'draw':
            return 0

        # The game is ongoing or in an undecided state
        # Check the current state of the board to assign a score
        score = 0

        # Check rows
        for i in range(3):
            if board.currentTurn.color == board.dumpFEN()[i * 3] == board.dumpFEN()[i * 3 + 1] == \
                    board.dumpFEN()[i * 3 + 2]:
                score += 0.1 if board.currentTurn == board.players[0] else -0.1

        # Check columns
        for i in range(3):
            if board.currentTurn.color == board.dumpFEN()[i] == board.dumpFEN()[i + 3] == \
                    board.dumpFEN()[i + 6]:
                score += 0.1 if board.currentTurn == board.players[0] else -0.1

        # Check diagonals
        if board.currentTurn.color == board.dumpFEN()[0] == board.dumpFEN()[4] == board.dumpFEN()[8]:
            score += 0.1 if board.currentTurn == board.players[0] else -0.1

        if board.currentTurn.color == board.dumpFEN()[2] == board.dumpFEN()[4] == board.dumpFEN()[6]:
            score += 0.1 if board.currentTurn == board.players[0] else -0.1

        return score

    @classmethod
    def getPossibleMoves(cls, repr):
        board = Board.loadFEN(repr)
        possible_moves = []

        for i in range(1, 4):
            for j in range(1, 4):
                if board.canMakeMove(i, j):
                    board.makeMove(i, j)
                    possible_moves.append((board.dumpFEN(), f'{i}{j}'))

        return possible_moves

    def play( self, input ):
        print(input)
        input = self.parseInput(input)
        status = self.board.play(*input)
        assert( status )

    def getYCoordinate(self, y):
        if y == 'a':
            return '1'
        elif y == 'b':
            return '2'
        else:
            return '3'

    # Parse and validate user input
    def parseInput( self, moveInput ):
        cleanedString = moveInput.replace(' ', '').replace('-', '')
        if cleanedString in valid_inputs:
            return self.getYCoordinate(cleanedString[1]) + cleanedString[0]
        else:
            return None

    # Get input from user
    def getInput(self):
        moveInput = None
        while moveInput is None:
            moveInput = self.parseInput( input( f'Please Enter Your Move ({self.board.currentTurn.name}): ' ) )
        return moveInput

    def run(self):
        # gameResult can be:
        # - ongoing: game is ongoing
        # - x: x wins
        # - o: o wins
        # - draw: game over and the result is draw

        gameResult = 'ongoing'
        while gameResult == 'ongoing':
            print( self.board.dump() )
            moveInput = self.getInput()
            status = self.board.play(*moveInput)
            if status == True:
                print("Move successful.")
            else:
                print("Invalid move. Try again.")

            gameResult = self.board.isGameOver()

        if gameResult == self.player1.color:
            print(f'{self.player1.color} wins')
        elif gameResult == self.player2.color:
            print(f'{self.player2.color} wins')
        else:
            print(' Draw! ')

        print(self.board.dump())