class Player:
    def __init__(self, name, color):
        self.name = name
        self.color = color
        self.moves = []
